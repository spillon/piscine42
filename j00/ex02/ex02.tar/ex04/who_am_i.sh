%>sh who_am_i.sh
uid=spillon,ou=2016_paris,ou=2016,ou=paris,ou=people,dc=42,dc=fr
%>
